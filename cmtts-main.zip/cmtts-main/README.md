# cmtts



#介绍
仓库地址 https://github.com/ciwei6107563/cmtts

如果需要修改内容 在index.html文件进行修改
* 图片是 img标签 
* 音频是 audio标签
* 修改文本全局搜索相关内容即可

# 部署
使用的平台是vercel
地址是 https://vercel.com/bfs-projects-fec62424

项目名是 cmtts

修改流程为
1. git clone 拉取github仓库的项目
2. 项目修改
3. 完成修改并提交代码
4. vercel 会自动同步提交的代码内容， 如果没有成功可以去平台的控制台查看部署的情况然后重新部署即可
5. 部署成功后刷新页面即可 部署的页面是 https://cmtts.vercel.app/